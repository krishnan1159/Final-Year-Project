import java.io.IOException;
import java.util.HashMap;
import java.util.List;

//$Id$

public class Test {
	
	public static void init()
	{
		System.out.println("Hello");
	}
	
	public static void main(String[] args) throws IOException {
		
		
		System.out.println("World");

	}
}
