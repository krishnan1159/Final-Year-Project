//$Id$

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;

class RuleObject
{
	Pattern Regex;
	boolean IS_REGEX_PRESENT;
	boolean RESULT_NEGATE;
	String Operator;
	String Op_Value;
	String[] Actions;
	List<String> Variables;
	HashSet<String> data;
	
	public RuleObject()
	{
		Regex    = null;
		Operator = null;
		Op_Value = null;
		Actions  = new String[5];//1.MSG 2.ACCURACY 3.SEVERITY 4.MATURITY 5.ID
		data     = new HashSet<String>();
		Variables= new ArrayList<String>();
	}
	
	public void addBooleans(boolean regex,boolean negate)
	{
		this.IS_REGEX_PRESENT = regex;
		this.RESULT_NEGATE    = negate;
	}
	
	public void addOpertor(String operator,String value)
	{
		this.Operator = operator;
		this.Op_Value = value;
	}
	
	public void addActions(String[] actions)
	{
		this.Actions = actions;
	}
	
	public void addVariables(String[] Variables)
	{
		for(String variable : Variables)
			this.Variables.add(variable);
	}
	
	public void addData(String Datas)
	{
		String[] temp = Datas.split(" ");
		for(String data : temp)
			this.data.add(data);
	}
}

