import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


//$Id$

public class RegexTest 
{
	public static void main(String[] args) throws IOException
	{
		System.out.println("Test");
		Pattern regex          = Pattern.compile("\"([^\\\\\"]|\\\\\")+\"");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println(regex.pattern());
		String line = br.readLine();
		System.out.println(line.length());
		Matcher regexMatcher   = regex.matcher(line);
		List<String> rule      = new ArrayList<String>();
		
		while(regexMatcher.find())
			rule.add(regexMatcher.group());
		System.out.println(rule.size());
		for(int i=0;i<rule.size();i++)
		{
			System.out.println(rule.get(i));
		}
	}
}
