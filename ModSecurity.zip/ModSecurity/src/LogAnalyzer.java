import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//$Id$

public class LogAnalyzer extends Rule
{
	List<RuleSet> ModSecurity_Core_RuleSet;
	public LogAnalyzer()
	{
		super();
		ModSecurity_Core_RuleSet = new ArrayList<RuleSet>();
	}
	
	public void init()
	{
		String[] ruleFiles   = {"modsecurity_crs_20_protocol_violations.conf",
				"modsecurity_crs_21_protocol_anomalies.conf",
				"modsecurity_crs_23_request_limits.conf",
				"modsecurity_crs_30_http_policy.conf",
				"modsecurity_crs_35_bad_robots.conf",
				"modsecurity_crs_40_generic_attacks.conf",
				"modsecurity_crs_41_sql_injection_attacks.conf",
				"modsecurity_crs_41_xss_attacks.conf",
				"modsecurity_crs_42_tight_security.conf",
				"modsecurity_crs_45_trojans.conf",
				"modsecurity_crs_47_common_exceptions.conf",
				"modsecurity_crs_49_inbound_blocking.conf",
				"modsecurity_crs_50_outbound.conf",
				"modsecurity_crs_59_outbound_blocking.conf",
				"modsecurity_crs_60_correlation.conf"};
		
		Pattern re = Pattern.compile("(?<=\\d\\d_)\\w+");
		String RuleSetName="";

		for(String filename : ruleFiles)
		{
			Matcher m = re.matcher(filename);
			if(m.find())
				RuleSetName = m.group();
			
			RuleSet ruleSet = new RuleSet(RuleSetName);
			
			List<String[]> rules = parseRuleFile(baseLocation+"/"+filename);
			
			for(String[] rule : rules)
				this.formRuleObject(ruleSet,rule);
			
			ModSecurity_Core_RuleSet.add(ruleSet);
		}
	}
	
	public void isAttacked(String logId,String variable,String value)
	{
		//System.out.println(variable+" VALUE "+value);
		for(RuleSet ruleSet : ModSecurity_Core_RuleSet)
		{
			List<String> ruleIds = ruleSet.varToId.get(variable);
			if(ruleIds == null)
				continue;
			
			for(String ruleId : ruleIds)
			{
				RuleObject ruleObject = ruleSet.idToRuleObject.get(ruleId);
				if(ruleObject.IS_REGEX_PRESENT)
				{
					Matcher matcher = ruleObject.Regex.matcher(value);
					
					if( !(ruleObject.RESULT_NEGATE) == matcher.find())
						System.out.println("An Attacked Occured. The log id is "+logId+"The Matched Rule is "+ruleObject.Actions[4]);
				}
			}
		}
	}
	
	public void checkForAttack(String logRecord)
	{
		System.out.println("-------------------------------------------------------------------------------------------------------");
		//System.out.println(this.r.idToRuleObject.size());
		String variable     = "";
		LogObject logObject = new LogObject(logRecord);
		String logId        = logObject.getReqID();
		
		Boolean[] isRuleOver = new Boolean[1000002]; /* Checking whether the rule is checked */
		Arrays.fill(isRuleOver, false);
		
		/* Attack in REQUEST_URI */
		variable             = "REQUEST_URI";
		isAttacked(logId,variable, logObject.getRequestURI());
		
		/* Attack in protocol */
		
		variable = "REQUEST_PROTOCOL";
		isAttacked(logId,variable, logObject.getProtocol());
		
		/* Attack in Method */
		variable = "REQUEST_METHOD";
		isAttacked(logId,variable,logObject.getMethod());
		
		/*Attack in referer*/
		variable = "REQUEST_HEADERS:Referer";
		isAttacked(logId,variable, logObject.getReferer());
		
		/*Attack in User-Agent*/
		variable = "REQUEST_HEADERS:User-Agent";
		isAttacked(logId,variable, logObject.getUserAgent());
		
		/*Attack in ARGS and ARGS_NAMES*/
		
		String[] args = logObject.getParams().split("&");
		for(String arg:args)
		{
			/*Attack in Args */
			String[] temp = arg.split("=");
			
			if(temp.length == 2)
			{
				variable = "ARGS_NAMES";
				isAttacked(logId,variable, temp[0]);
				variable = "ARGS";
				isAttacked(logId,variable,temp[1]);
			}
		}
		
		System.out.println("-------------------------------------------------------------------------------------------------------");
		System.out.println();
	}
	
	public void analyzeLog(File logFile)
	{
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(logFile)));
			
			br.readLine();
			String logRecord;
			while( (logRecord = br.readLine()) != null )
			{
				checkForAttack(logRecord);
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args)
	{
		LogAnalyzer logAnalyzer = new LogAnalyzer();
		logAnalyzer.init();
		
		File logFile = new File("/home/hduser/zoho/test.txt");
		logAnalyzer.analyzeLog(logFile);
	}
}
