//$Id$

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public abstract class RuleParser 
{
	protected static final String REGEX_RULE = "(?:\"(?:[^\"\\\\]++|\\\\.)*+\"|[^\\s\"]++)++";
	protected static final String baseLocation  = "/home/hduser/zoho/owasp-modsecurity-crs/base_rules/";
	protected static final Pattern regex = Pattern.compile(REGEX_RULE);
	
	public List<String[]> parseRuleFile(String filename)
	{
		List<String[]> rules = new ArrayList<String[]>();
		/* Read the File */
		try 
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
			String line="";
			String ruleToMatch="";
			
			while( (line=br.readLine()) != null)
			{
				if(line.length() > 0 && line.charAt(line.length()-1) == '\\')
				{
					ruleToMatch += line.substring(0, line.length()-1);
					continue;
				}
				ruleToMatch +=line;
				Matcher regexMatcher   = regex.matcher(ruleToMatch);
				List<String> rule      = new ArrayList<String>();
				
				while(regexMatcher.find())
					rule.add(regexMatcher.group());
				
				String[] singleRule = rule.toArray(new String[0]);
				if(singleRule.length > 0 && singleRule[0].equalsIgnoreCase("SecRule"))
				{
					rules.add(singleRule);
				}
				
				ruleToMatch ="";
			}
			br.close();
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rules;
	}
}
