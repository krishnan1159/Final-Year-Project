//$Id$

public class LogObject 
{
	private String[] logFields;
	public LogObject()
	{
		logFields = new String[24];
	}
	public LogObject(String logRecord)
	{
		logFields = new String[24];
		String[] temp = logRecord.split(" ");
		for(int i=0;i<24;i++)
			this.logFields[i] = temp[i];
	}
	public LogObject(String[] logField)
	{
		for(int i=0;i<24;i++)
			this.logFields[i] = logField[i];
	}
	public String getReqID()
	{
		return logFields[0];
	}
	public String getServiceName()
	{
		return logFields[1];
	}
	public String getAppIP()
	{
		return logFields[2];
	}
	
	public String getAccount()
	{
		return logFields[3];
	}
	
	public String getRemoteIP()
	{
		return logFields[4];
	}

	public String getZUID()
	{
		return logFields[5];
	}

	public String getTicketDigest()
	{
		return logFields[6];
	}

	public String getSessionID()
	{
		return logFields[7];
	}

	public String getThreadID()
	{
		return logFields[8];
	}

	public String getProtocol()
	{
		return logFields[9];
	}

	public String getServerName()
	{
		return logFields[10];
	}

	public String getServerPort()
	{
		return logFields[11];
	}

	public String getMethod()
	{
		return logFields[12];
	}

	public String getRequestURI()
	{
		return logFields[13];
	}

	public String getParams()
	{
		return logFields[14];
	}

	public String getReferer()
	{
		return logFields[15];
	}

	public String getInternalIP()
	{
		return logFields[16];
	}

	public String getUserAgent()
	{
		return logFields[17];
	}

	public String getBytesIn()
	{
		return logFields[18];
	}

	public String getBytesOut()
	{
		return logFields[19];
	}

	public String getStatus()
	{
		return logFields[20];
	}

	public String getTimeTaken()
	{
		return logFields[21];
	}

	public String getTimeStamp()
	{
		return logFields[22];
	}

	public String getLBIP()
	{
		return logFields[23];
	}
	
}
