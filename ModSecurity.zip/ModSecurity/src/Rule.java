 import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

//$Id$
public class Rule extends RuleParser
{
	public String readFromFile(String FileName)
	{
		String content = "";
		try 
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(baseLocation+"/"+FileName)));
			String line;
			while((line = br.readLine()) != null)
				content+=line+" ";
			br.close();
			
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		return content;
	}
	
	public String[] formRuleVariable(String Variable)
	{
		List<String> result = new ArrayList<String>(); /* Dynamic String Array */
		String[] temp = Variable.split("\\|");
		
		for(String var : temp)
			if(var.charAt(0) != '!' && var.charAt(0) !='&')
				result.add(var);
			else if(var.charAt(0) == '&')
				result.add(var.substring(1));
				
		return result.toArray(new String[result.size()]); /* Study how it works */
	}
	
	public String escapeSpecialChars(String input)
	{
		input = input.replace("\\", "\\\\");
		input = input.replace("\"", "\\\"");
		input = input.replace("'", "\\'");
		input = input.replace("[", "\\[");
		input = input.replace("]", "\\]");
		input = input.replace("(", "\\(");
		input = input.replace(")", "\\)");
		input = input.replace("{", "\\{");
		input = input.replace("}", "\\}");
		input = input.replace("/", "\\/");
		input = input.replace("-", "\\-");
		
		return input;
	}
	
	public String[] formRuleOperator(String Operator)
	{
		String[] result = new String[4]; /* 1. IS_REGEX_PRESENT 2. OP_NAME 3. OP_VALUE 4.Regex Negate */
		result[0] = "true";
		result[3] = "false";
		
		if(!Operator.startsWith("!@") && !(Operator.charAt(0) == '@') )
		{
			result[1] = "regex";
			result[2] = Operator;
			return result;
		}
		//System.out.println(Operator);
		
		String[] temp  = Operator.split(" "); // Temp[0] - Operator Temp[1] - Op_Value
		String opValue = "";
		if(temp.length < 2) //No OpValue for urlencoding
			opValue = "NULL";
		else
		{
			opValue = temp[1];
			temp[1] = escapeSpecialChars(temp[1]);
		}
		result[1]      = temp[0];
		
		if( result[1].charAt(0) == '!')     //Operator might start with !. Remove that and re-assign to temp[0]
		{
			temp[0]   = temp[0].substring(1);
			result[1] = temp[0];
			result[3] = "true";
		}
		
		if(temp[0].equalsIgnoreCase("@beginsWith"))
		{	
			result[2]="^"+temp[1];
		}
		else if(temp[0].equalsIgnoreCase("@contains"))
		{
			result[2] = temp[1];
		}
		else if(temp[0].equalsIgnoreCase("@containsWord"))
		{
			result[2] = "\\b"+temp[1]+"\\b";
		}
		else if(temp[0].equalsIgnoreCase("@endsWith"))
		{
			result[2] = temp[1]+"$";
		}
		else if(temp[0].equalsIgnoreCase("@eq") || temp[0].equalsIgnoreCase("@le") || temp[0].equalsIgnoreCase("@lt") || temp[0].equalsIgnoreCase("@ge") || temp[0].equalsIgnoreCase("@gt") || temp[0].equalsIgnoreCase("@validateByteRange") || temp[0].equalsIgnoreCase("@validateUrlEncoding") || temp[0].equalsIgnoreCase("validateUtf8Encoding") || temp[0].equalsIgnoreCase("@within"))
		{
			result[0] = "false";
			result[2] = opValue;
		}
		else if(temp[0].equalsIgnoreCase("@streq"))
		{
			result[2] = "^"+temp[1]+"$";
		}
		else if(temp[0].equalsIgnoreCase("@strmatch"))
		{
			result[2] = temp[1];
		}
		else if(temp[0].equalsIgnoreCase("@pm"))
		{
			String res = "";
			for(int i=1;i<temp.length-1;i++)
				res += temp[i]+"|";
		//	System.out.println("Rule"+temp[temp.length-1]);
			res += temp[temp.length-1];
			res = escapeSpecialChars(res);
			res = "("+res+")";
			result[2] = res; 
		}
		else if(temp[0].equalsIgnoreCase("@pmFromFile") || temp[0].equalsIgnoreCase("@pmf"))
		{
			result[0] = "false";
			result[2] = readFromFile(temp[1]);
		}
		
		return result;
	}
	
	public String[] formRuleAction(String Action)
	{
		String[] result = new String[5];//1.MSG 2.ACCURACY 3.SEVERITY 4.MATURITY 5.ID
		result[0] = "No Message";
		result[1] = "No Accuracy";
		result[2] = "No Severity";
		result[3] = "No Maturity";
		result[4] = "No Id";
		String temp[] = Action.split(",");
		for(String action : temp)
		{
			if( action.startsWith("msg:"))
			{
				result[0] = action.split(":")[1];
			}
			else if( action.startsWith("accuracy:"))
			{
				result[1] = action.split(":")[1];
			}
			else if( action.startsWith("severity:") )
			{
				result[2] = action.split(":")[1];
			}
			else if( action.startsWith("maturity:"))
			{
				result[3] = action.split(":")[1];
			}
			else if( action.startsWith("id:") )
			{
				result[4] = action.split(":")[1];
			}
		}
		return result;
	}
	
	
	public void formRuleObject(RuleSet ruleSet,String[] rule)
	{
		if(rule.length < 4 )
			return;
		RuleObject resultObject = new RuleObject();
		/* Form Variables */
		String[] variable = formRuleVariable(rule[1]);
		
		/* Testing for Variables
		 * 
		 * for(String var : variable)
		{
			System.out.print(i+" "+var+" ");
			i++;
		}
		System.out.println();*/
		
		/* Form Operators */
		String[] operator = formRuleOperator(rule[2].substring(1, rule[2].length()-1)); /* 1. IS_REGEX_PRESENT 2. OP_NAME 3. OP_VALUE 4.Regex Negate */
		
		/*for(int i=0;i<operator.length;i++)
			System.out.print(operator[i]+" ");
		System.out.println();*/
		
		
		/* Form Actions */
		
		String[] actions  = formRuleAction(rule[3]); //1.MSG 2.ACCURACY 3.SEVERITY 4.MATURITY 5.ID 
		/*for(int i=0;i<actions.length;i++)
			System.out.print(actions[i]+ " ");
		System.out.println();*/
		
		if(actions[4].equalsIgnoreCase("No Id"))
		{
			//System.out.println("RULE ERROR : No Rule Id");
			return;
		}
		
		resultObject.IS_REGEX_PRESENT = Boolean.valueOf(operator[0]);
		resultObject.RESULT_NEGATE    = Boolean.valueOf(operator[3]);	
		resultObject.Operator         = operator[1];
		resultObject.Op_Value         = operator[2];
		
		try
		{
			if(resultObject.IS_REGEX_PRESENT)
				resultObject.Regex = Pattern.compile(operator[2]);
		}
		catch(Exception e)
		{
			//System.out.println("REGEX ERROR: Rule ID ---->"+actions[4]);
			return;
		}
		resultObject.Actions          = actions;
		resultObject.addVariables(variable);
		if(resultObject.Operator.equalsIgnoreCase("@pmFromFile"))
			resultObject.addData(operator[2]);
		
		/* Map Variable to Id's */
		
		for(String var : variable)
		{
			if(ruleSet.varToId.get(var) == null)
				ruleSet.varToId.put(var,new ArrayList<String>());
			ruleSet.varToId.get(var).add(actions[4]);
		}
		
		/* Map Id to Rule Object */
		
		ruleSet.idToRuleObject.put(actions[4], resultObject);
		
	}
	
	/*public static void main(String[] args)
	{
		Rule                r = new Rule();
		RuleParser ruleParser = new RuleParser(); // Reads every file and return List of rules
		
		r.rules.addAll(ruleParser.updateRule());
		
		for(String[] rule : r.rules)
		{
				r.formRuleObject(rule);
		}
				
	}*/
}
