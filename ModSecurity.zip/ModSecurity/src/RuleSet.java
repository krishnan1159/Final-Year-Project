import java.util.HashMap;
import java.util.List;


//$Id$

public class RuleSet 
{
	private String name;
	private String description;
	HashMap<String,List<String>> varToId;
	HashMap<String,RuleObject> idToRuleObject;
	
	public String getName()
	{
		return this.name;
	}
	public String getDescription()
	{
		return this.description;
	}
	
	public RuleSet(String name)
	{
		this.name = name;
		this.description = "";
		this.varToId        = new HashMap<String, List<String>>();
		this.idToRuleObject = new HashMap<String, RuleObject>();
	}
	
	public RuleSet(String name,String description)
	{
		this.name = name;
		this.description = description;
		this.varToId        = new HashMap<String, List<String>>();
		this.idToRuleObject = new HashMap<String, RuleObject>();
	}
}
